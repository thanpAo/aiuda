from flask import Flask, render_template, Response, request, jsonify
import cv2
import numpy as np
import mediapipe as mp

app = Flask(__name__)

# Configuración de MediaPipe para la detección del cuerpo
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

# Variables globales para almacenar la imagen cargada, tipo y tamaño escalado
uploaded_image = None
image_type = None
scaled_overlay = None  # Almacena el overlay escalado

def add_alpha_channel(image):
    """Agrega un canal alfa a la imagen si no tiene uno."""
    if image.shape[2] == 3:  # Si solo tiene 3 canales (RGB)
        b, g, r = cv2.split(image)
        alpha = np.ones(b.shape, dtype=b.dtype) * 255  # Canal alfa con opacidad completa
        image = cv2.merge((b, g, r, alpha))
    return image

def get_overlay_scale_size(frame_shape, body_part):
    """
    Define el tamaño de escalado de uploaded_image en función de la parte del cuerpo detectada.
    """
    frame_h, frame_w = frame_shape[:2]
    # Tamaños de escala ajustados para cada prenda
    if body_part == "sombrero":
        return (int(0.25 * frame_w), int(0.25 * frame_h))
    elif body_part == "camiseta":
        return (int(0.35 * frame_w), int(0.35 * frame_h))
    elif body_part == "pantalones":
        return (int(0.3 * frame_w), int(0.4 * frame_h))
    return None

def overlay_png(frame, overlay, position):
    """
    Superpone el overlay escalado con transparencia sobre el frame en la posición especificada,
    permitiendo que se salga de los límites del frame si es necesario.
    """
    y, x = position
    h, w, _ = overlay.shape
    frame_h, frame_w = frame.shape[:2]

    # Ajustar el área de superposición para no salirse de los límites del frame
    y1, y2 = max(0, y), min(y + h, frame_h)
    x1, x2 = max(0, x), min(x + w, frame_w)
    overlay_y1, overlay_y2 = max(0, -y), min(h, frame_h - y)
    overlay_x1, overlay_x2 = max(0, -x), min(w, frame_w - x)

    # Crear una copia de la sección del frame donde se aplicará el overlay
    if y1 < y2 and x1 < x2:  # Solo superponer si la región es válida
        frame_section = frame[y1:y2, x1:x2]
        overlay_section = overlay[overlay_y1:overlay_y2, overlay_x1:overlay_x2]

        # Superposición con transparencia
        alpha_overlay = overlay_section[:, :, 3] / 255.0
        alpha_frame = 1 - alpha_overlay

        for c in range(3):
            frame_section[:, :, c] = (
                alpha_overlay * overlay_section[:, :, c] + alpha_frame * frame_section[:, :, c]
            )

    return frame

def get_position(landmarks, body_part, frame):
    """
    Determina la posición de una parte del cuerpo en función de los puntos de referencia de la pose.
    """
    frame_h, frame_w = frame.shape[:2]
    
    if body_part == "sombrero":
        x = int(landmarks[mp_pose.PoseLandmark.NOSE].x * frame_w) - 70
        y = int(landmarks[mp_pose.PoseLandmark.NOSE].y * frame_h) - 190  # Más arriba para el sombrero
    elif body_part == "camiseta":
        x = int(landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER].x * frame_w) - 160
        y = int(landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER].y * frame_h) + -10  # Alineación en el torso
    elif body_part == "pantalones":
        x = int(landmarks[mp_pose.PoseLandmark.LEFT_HIP].x * frame_w) - 30
        y = int(landmarks[mp_pose.PoseLandmark.LEFT_HIP].y * frame_h) + 20  # Más abajo para las caderas
    else:
        x, y = 0, 0
    return (y, x)

def generate_frames():
    """
    Genera los frames para la cámara en tiempo real, detectando el cuerpo y superponiendo el PNG cargado.
    """
    cap = cv2.VideoCapture(0)
    global uploaded_image, image_type, scaled_overlay

    while True:
        success, frame = cap.read()
        if not success:
            break
        
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(frame_rgb)

        # Si hay detección de pose y hay una imagen cargada
        if results.pose_landmarks and scaled_overlay is not None:
            landmarks = results.pose_landmarks.landmark
            
            # Obtener la posición según el tipo de imagen
            position = get_position(landmarks, image_type, frame)
            
            # Superponer la imagen en la posición detectada
            frame = overlay_png(frame, scaled_overlay, position)

        # Convertir a JPEG para el streaming en tiempo real
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/upload', methods=['POST'])
def upload():
    global uploaded_image, image_type, scaled_overlay
    if 'file' in request.files:
        file = request.files['file']
        image_type = request.form.get('type')  # Obtener el tipo de prenda
        uploaded_image = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_UNCHANGED)
        uploaded_image = add_alpha_channel(uploaded_image)  # Asegura que tenga un canal alfa

        # Escalar uploaded_image solo una vez al tamaño adecuado
        frame_dummy = np.zeros((480, 640, 3), dtype=np.uint8)  # Tamaño típico de cámara 640x480
        scale_size = get_overlay_scale_size(frame_dummy.shape, image_type)
        if scale_size:
            scaled_overlay = cv2.resize(uploaded_image, scale_size, interpolation=cv2.INTER_AREA)
        else:
            scaled_overlay = uploaded_image  # Por defecto, sin escalado
        
        return jsonify(success=True)
    return jsonify(success=False)
  
if __name__ == '__main__':
    app.run(debug=True)